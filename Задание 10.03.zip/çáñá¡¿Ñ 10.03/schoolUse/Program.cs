﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using classSchool;



namespace schoolUse
{
    class Program
    {
        public static Class1 cls = new Class1();
        static void Main(string[] args)
        {
            List<Mark> marks = new List<Mark>();

            List<Students> students = new List<Students>
            {
                new Students(2018,818,"Васильев Иван Владимирович"),
                new Students(2021,821,"Покасанов Вячеслав Андреевич"),
                new Students(2018,818,"Рябов Филипп Сергеевич"),
                new Students(2019,819,"Дёмин Артём Дмитриевич"),
                new Students(2019,819,"Евтеев Денис Владимирович"),
                new Students(2020,820,"Воронин Артём Дмитриевич"),
                new Students(2020,820,"Пушков Владимир Владимирович"),
                new Students(2021,821,"Логвинов Виктор Сергеевич"),
                new Students(2022,822,"Маркина Анастасия Вячеславовна"),
                new Students(2022,822,"Серёгин Андрей Владимирович"),
                new Students(2022,822,"Коробов Владислав Дмитриевич")
            };

            //Заполнение оценками
            marks.AddRange(cls.GetMarks(DateTime.Parse("01.01.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("09.02.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("21.03.2022"), students)); 
            marks.AddRange(cls.GetMarks(DateTime.Parse("09.04.2022"), students));
            marks.AddRange(cls.GetMarks(DateTime.Parse("09.05.2022"), students));

            //Вывод всех оценок
            foreach (Mark m in marks)
            {
                Console.WriteLine($"{m.date.ToString("dd.MM.yyyy")}\t{m.Estimation} - {m.student.fio}");
            }
            Console.WriteLine();

            //Вывод прогулов за месяцы
            foreach (int i in cls.GetCountTruancy(marks))
            {
                Console.WriteLine(i);

            }
            Console.WriteLine();

            //Вывод болезней за месяц
            foreach (int i in cls.GetCountDisease(marks))
            {
                Console.WriteLine(i);

            }
            Console.WriteLine();

            //Студенческие билеты студентов
            foreach(Students std in students)
            {
                Console.WriteLine(cls.GetStudNumber(std.year, std.group, std.fio));
            }
            Console.WriteLine();

            //Среднее арифметическое оценок в меньшую сторону
            Console.WriteLine(cls.MinAVG(new string[6]{ "4","2","5","б","п"," "}));
            Console.ReadKey();

        }
    }
}
